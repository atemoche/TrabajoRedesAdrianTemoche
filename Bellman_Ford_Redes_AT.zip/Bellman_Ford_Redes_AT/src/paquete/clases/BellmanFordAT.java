/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.io.*;

/**
 *
 * @author Adrian Temoche
 */
public class BellmanFordAT {
//Acá se declaran las variables que se van a utilizar para la correcta ejecución del código
    //VerOrigen se refiere al Vertice Origen del cual se va a partir para los demas vertices
    private static int VerOrigen;
    //NumVertice se refiere al numeros de Vertices
    private static int NumVertice;
    //txt hace referencia a la matriz donde se alamcenara las conexiones entre vertices con sus pesos
    private static String[][] txt;
    //NumAristas me va a servir para contar la cantidad de aristas del grafo
    private static int NumAristas = 0;
    //Valor maximo me va a servir como referencia del peso máximo que una arista podra tener
    public static final int VALORMAX = 999;
    
    //Este es el metodo BellmanFord el cual hara el calculo de los caminos más cortos
    public static void BellmanFord(int inicio, String matriz[][], int cantVertice){
        //El arreglo distancia almacenara el peso de ir cada vertice
        int distancia[]= new int[cantVertice];
        //El arista previo almacenara el Vertice origen que va hacia el destino
        int previo[] = new int[cantVertice];
        //El for nos va a servir para llenar el arreglo distancia con el valor maximo
        for (int nodo = 0; nodo < NumVertice; nodo++)
        {
            distancia[nodo] = VALORMAX;
        }
 //El for vertice va a hacer que se repita los otros dos FOR el Numero de vertices -1, con el objetivo de recorrer todo los vertices 
 //sin importar donde se empiece y se actualize los valores
        distancia[inicio] = 0;
        for (int vertice = 0; vertice < NumVertice - 1; vertice++)
        {
            //Este FOR se usa para los vertices de Origen
            for (int origen = 0; origen < NumVertice; origen++)
            {
                //Este FOR se usa para los vertices de destino
                for (int destino = 0; destino < NumVertice; destino++)
                {
                    //Acá se corrobora que solo entren las arista con peso diferente al valor maximo
                    if (Integer.valueOf(matriz[origen][destino]) != VALORMAX)
                    {
                        //Acá suscede el proceso de relajación donde se compara si el peso del vertice destino es mayor que
                        //el peso del vertice orgien + el peso de la arista
                        if (distancia[destino] > distancia[origen] + Integer.valueOf(matriz[origen][destino]))
                        {
                            //Si se cumple la condición, es decir que el peso de la arista + peso vertice origen es menor
                            //que el peso del vertice destino, se sobre escribe el peso del vertice destino
                            distancia[destino] = distancia[origen] + Integer.valueOf(matriz[origen][destino]);
                            previo[destino] = origen;
                        }
                    }
                }
            }
        }
 //Este FOR realiza casi lo mismo que los for anterior, pero difiere en que acá me ayuda a saber si hay cilcos negativos
        for (int origendos = 0; origendos < NumVertice; origendos++)
        {
            for (int destinodos = 0; destinodos < NumVertice; destinodos++)
            {
                if (Integer.valueOf(matriz[origendos][destinodos]) != VALORMAX)
                {
                    if (distancia[destinodos] > distancia[origendos] + Integer.valueOf(matriz[origendos][destinodos]))
                    {
                        //Si se encuentra acá que el peso de la arista + peso vertice origen es menor que el peso del vertice destino
                        //Se imprime un mensaje que dira que el grafo contiene un ciclo negativo
                        System.out.println("El grafo contiene un ciclo negativo");
                    }
                }
            }
        }
        
//Esta parte me sirve para imprimir los vertices, el peso de la distancia desde el Vertice origen hacia los otros vertices
//y saber cual fue el vertice anterior por el que paso
        previo[VerOrigen]=-1;
        System.out.println();
        System.out.println("Tabla del Algoritmo Bellman-Ford");
        System.out.println("Vertices" + "\t" + "Distancia" + "\t" + "Previos");
        for (int k = 0; k < distancia.length; k++) {
            System.out.println("Vertice " + (k+0) + "\t"+"    " + distancia[k] +"\t\t" + "  "+ previo[k]);  
        }

    }
   
//Este metodo me sirve para llenar la Matriz para que se cumpla la condición de los For de arriba
    //Sino se cambiara los 0 por valor MAX el resultado siempre me daria 0
    public static void llenarMatriz(int cantVertices,String matriz[][],int maxValor){
        
        for (int origen = 0; origen < cantVertices; origen++)
        {
            for (int destino = 0; destino < cantVertices; destino++)
            {
                
 	        if (origen == destino)
                {  
                    matriz[origen][destino] = "0";
                    continue;
                }
                if (matriz[origen][destino] == "0")
                {               
                    matriz[origen][destino] = String.valueOf(maxValor);
                }
            }
        }
    }
//Este es el metodo utilizado para capturar el archivo en su ubicación
    //Se utiliza las librerias java.io.*
    public static BufferedReader leer(String link){

    FileReader lector  = null;
    BufferedReader br = null;
    try {
         File Arch=new File(link);
        if(!Arch.exists()){
           System.out.println("No existe el archivo");
        }else{
           lector = new FileReader(link);
           br = new BufferedReader(lector);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return br;
}
//Una vez se captura el archivo txt se empieza a leer su contenido
    public static void readTxt(String ruta){
    try {
        
        BufferedReader br = leer(ruta);
        //leemos la primera linea
        String linea =  br.readLine();
        NumVertice = Integer.parseInt(linea);
        //leemos la segunda linea
        linea = br.readLine();
        VerOrigen = Integer.parseInt(linea);
        //leemos la tercera linea
        linea =br.readLine();
        //creamos la matriz y la llenamos de 0
        txt = new String[NumVertice][NumVertice];
        
        for (int i = 0; i < txt.length; i++) {
            for (int j = 0; j < txt.length; j++) {
                txt[i][j] = "0";
            }
        }
        
        while(linea != null){
            String[] values = linea.split("/");
            String Origen="", Destino="", Peso="";
            //recorremos el arrar de string
            //se obtiene los tres valores separados por un /
            
            Origen = values[0];
            Destino = values[1];
            Peso = values[2];
            //Se insertan en la matriz txt el peso en las coordenadas Origen, Destino
            txt[Integer.parseInt(Origen)][Integer.parseInt(Destino)] = Peso;
            //System.out.println(Origen+"\t"+Destino+"\t"+Peso);
            if (Integer.parseInt(Peso) != 999) {
                NumAristas++;
            }
            linea = br.readLine();
        }
        //SIRVE PARA IMPRIMIR LA MATRIZ ORIGINAL
        System.out.println("La matriz que se genera sería:");
        for (int i = 0; i < NumVertice; i++) {
            System.out.print("\t"+"V"+i);
        }
        System.out.println();
        for (int i = 0; i < NumVertice; i++) {
            System.out.print("V"+i+"\t");
            for (int j = 0; j < txt.length; j++) {

                System.out.print(txt[i][j] + "\t");
            }
            System.out.println();
        }
        
    } catch (IOException | NumberFormatException e) {
        e.printStackTrace();
    } 
}
    
    public static void main(String[] args) {
        //El comando System.nanoTime me sirve para medir el tiempo de demora del programa
        long Inicio = System.nanoTime();
        
        //ESCRIBIR LA RUTA DE LA UBICACIÓN DEL ARCHIVO AQUÍ, NO CONFUNDIR LA RUTA
        
        //String ruta = "C:\\Users\\Adrian Temoche\\Desktop\\ULIMA\\2020-2\\Redes de Computadoras\\Trabajo del Curso\\EscenarioBajo.txt";
        String ruta = "C:\\Users\\Adrian Temoche\\Desktop\\ULIMA\\2020-2\\Redes de Computadoras\\Trabajo del Curso\\EscenarioMedio.txt";
        //String ruta = "C:\\Users\\Adrian Temoche\\Desktop\\ULIMA\\2020-2\\Redes de Computadoras\\Trabajo del Curso\\EscenarioAlto.txt";
        
        readTxt(ruta);      
        
        llenarMatriz(NumVertice, txt, VALORMAX);
        
        System.out.println();
        System.out.println("El número de Vertices: " + NumVertice);
        System.out.println("El Vertice de Origen: " + VerOrigen);
        System.out.println("El número de Aristas es: " + NumAristas);
        
        BellmanFord(VerOrigen, txt, NumVertice); 
       
        long Fin = System.nanoTime();
        double dif = (Fin - Inicio)* 1.0e-9;
        //Imprimer la cantidad de segundos que demoró el programa
        System.out.println("El programa duró: " + dif+ " Segundos");
        
        int datasize = 1024 *1024;
        
        Runtime runtime = Runtime.getRuntime();
        
        //System.out.println("Memoria máxima: " + runtime.maxMemory() / datasize + "MB");
        System.out.println("Memoria Total: "+ runtime.totalMemory()/ datasize + "MB");
        System.out.println("Memoria Libre: "+ runtime.freeMemory() / datasize + "MB");
        System.out.println("Memoria usada: "+ (runtime.totalMemory() - runtime.freeMemory()) / datasize + "MB");
        
    }
    
}
